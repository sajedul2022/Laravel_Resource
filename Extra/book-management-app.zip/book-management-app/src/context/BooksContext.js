import React from 'react';

const BooksContext = React.createContext();

export default BooksContext;
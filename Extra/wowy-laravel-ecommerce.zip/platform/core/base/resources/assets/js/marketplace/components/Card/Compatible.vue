<template>
    <small class="mt-2 card-text">
        <i class="fa-solid fa-check fw-bold px-2 text-success"></i>
        {{ __('base.compatible_version') }}
    </small>
</template>

<script>

export default {
    name: 'marketplace-card-compatible',
}
</script>
